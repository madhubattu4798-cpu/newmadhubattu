ALTER TABLE "site_reviews" ADD COLUMN "status" text DEFAULT 'pending' NOT NULL;--> statement-breakpoint
UPDATE "site_reviews" SET "status" = 'approved';
