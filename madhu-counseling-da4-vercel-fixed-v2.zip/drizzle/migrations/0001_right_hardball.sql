CREATE TABLE "site_photos" (
	"id" text PRIMARY KEY NOT NULL,
	"src" text NOT NULL,
	"alt" text NOT NULL,
	"created_at" text DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "site_reviews" (
	"id" text PRIMARY KEY NOT NULL,
	"client_name" text NOT NULL,
	"body" text NOT NULL,
	"created_at" text DEFAULT now() NOT NULL
);
