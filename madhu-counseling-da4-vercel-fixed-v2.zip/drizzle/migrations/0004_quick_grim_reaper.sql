ALTER TABLE "booking_requests" ADD COLUMN "session_type" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "booking_requests" ADD COLUMN "amount" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "booking_requests" ADD COLUMN "payment_option" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "booking_requests" ADD COLUMN "payment_screenshot_url" text DEFAULT '' NOT NULL;