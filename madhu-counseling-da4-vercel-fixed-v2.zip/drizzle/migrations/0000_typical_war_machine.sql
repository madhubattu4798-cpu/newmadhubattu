CREATE TABLE "booking_requests" (
	"id" text PRIMARY KEY NOT NULL,
	"full_name" text NOT NULL,
	"contact" text NOT NULL,
	"service" text NOT NULL,
	"preferred_slot" text NOT NULL,
	"status" text DEFAULT 'new' NOT NULL,
	"created_at" text DEFAULT now() NOT NULL
);
