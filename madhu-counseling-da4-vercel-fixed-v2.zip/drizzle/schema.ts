import { sql } from "drizzle-orm";
import { integer, pgTable, text } from "drizzle-orm/pg-core";

export const bookingRequests = pgTable("booking_requests", {
  id: text("id").primaryKey(),
  fullName: text("full_name").notNull(),
  contact: text("contact").notNull(),
  service: text("service").notNull(),
  sessionType: text("session_type").notNull().default(""),
  preferredSlot: text("preferred_slot").notNull(),
  amount: integer("amount").notNull().default(0),
  paymentOption: text("payment_option").notNull().default(""),
  paymentScreenshotUrl: text("payment_screenshot_url").notNull().default(""),
  status: text("status").notNull().default("new"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const sitePhotos = pgTable("site_photos", {
  id: text("id").primaryKey(),
  src: text("src").notNull(),
  alt: text("alt").notNull(),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const siteReviews = pgTable("site_reviews", {
  id: text("id").primaryKey(),
  clientName: text("client_name").notNull(),
  body: text("body").notNull(),
  service: text("service").notNull().default(""),
  status: text("status").notNull().default("pending"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});
