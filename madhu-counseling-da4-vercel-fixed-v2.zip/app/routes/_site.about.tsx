import { About, SITE_NAME } from "@/components/site/SiteContent";

export function meta() {
  return [{ title: `About | ${SITE_NAME}` }];
}

export default function AboutPage() {
  return <About />;
}
