import { Faq, SITE_NAME } from "@/components/site/SiteContent";

export function meta() {
  return [{ title: `FAQ | ${SITE_NAME}` }];
}

export default function FaqPage() {
  return <Faq />;
}
