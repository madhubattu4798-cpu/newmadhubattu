import {
  AdminPanel,
  CrisisNotice,
  Credentials,
  Hero,
  HomeSessionFees,
  ReviewSubmission,
  SessionGallery,
  SITE_NAME,
  Testimonials,
  Why,
} from "@/components/site/SiteContent";

export function meta() {
  return [
    { title: SITE_NAME },
    {
      name: "description",
      content:
        "Professional, compassionate, and 100% confidential psychological counseling with Madhu Battu.",
    },
  ];
}

export default function HomePage() {
  return (
    <>
      <Hero />
      <Credentials />
      <Why />
      <HomeSessionFees />
      <SessionGallery />
      <CrisisNotice />
      <ReviewSubmission />
      <Testimonials />
      <AdminPanel />
    </>
  );
}
