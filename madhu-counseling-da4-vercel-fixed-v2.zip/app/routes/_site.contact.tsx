import { Contact, SITE_NAME } from "@/components/site/SiteContent";

export function meta() {
  return [{ title: `Contact | ${SITE_NAME}` }];
}

export default function ContactPage() {
  return <Contact />;
}
