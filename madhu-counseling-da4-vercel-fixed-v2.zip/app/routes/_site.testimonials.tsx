import { Testimonials, SITE_NAME } from "@/components/site/SiteContent";

export function meta() {
  return [{ title: `Testimonials | ${SITE_NAME}` }];
}

export default function TestimonialsPage() {
  return <Testimonials />;
}
