import { Services, SITE_NAME } from "@/components/site/SiteContent";

export function meta() {
  return [{ title: `Services | ${SITE_NAME}` }];
}

export default function ServicesPage() {
  return <Services />;
}
