import { useEffect } from "react";
import { Outlet, useLocation } from "react-router";

import { Footer, FloatingActions, Header } from "@/components/site/SiteContent";

export default function SiteLayout() {
  const { pathname, hash } = useLocation();

  useEffect(() => {
    if (hash) {
      document.getElementById(hash.slice(1))?.scrollIntoView();
      return;
    }
    document.querySelector(".agent-native-app-main")?.scrollTo(0, 0);
  }, [pathname, hash]);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main>
        <Outlet />
      </main>
      <Footer />
      <FloatingActions />
    </div>
  );
}
