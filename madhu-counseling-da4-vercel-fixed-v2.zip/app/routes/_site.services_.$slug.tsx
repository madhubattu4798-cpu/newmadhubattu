import { useParams } from "react-router";

import { findService, ServiceDetail, SITE_NAME } from "@/components/site/SiteContent";

export function meta({ params }: { params: { slug?: string } }) {
  const service = findService(params.slug ?? "");
  return [{ title: `${service?.title ?? "Service"} | ${SITE_NAME}` }];
}

export default function ServiceDetailPage() {
  const { slug = "" } = useParams();
  return <ServiceDetail slug={slug} />;
}
