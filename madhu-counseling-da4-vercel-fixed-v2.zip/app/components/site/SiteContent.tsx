import {
  IconActivity,
  IconBrain,
  IconBrandInstagram,
  IconBrandWhatsapp,
  IconBriefcase,
  IconCalendarEvent,
  IconCompass,
  IconCheck,
  IconGift,
  IconHeartHandshake,
  IconHome,
  IconLeaf,
  IconLock,
  IconMail,
  IconMapPin,
  IconMenu2,
  IconMessageCircle,
  IconMoodSad,
  IconPhone,
  IconQuestionMark,
  IconRobot,
  IconSeedling,
  IconStar,
  IconPlus,
  IconTarget,
  IconTrash,
  IconUser,
  IconUsers,
  IconVideo,
  IconWind,
  IconX,
} from "@tabler/icons-react";
import { useEffect, useState, type ChangeEvent, type FormEvent } from "react";

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  allowedSessionTypes,
  COUPLE_SERVICE,
  formatRupees,
  PAYMENT_OPTIONS,
  type PaymentOptionId,
  SESSION_TYPES,
  type SessionTypeId,
  sessionAmount,
} from "@/lib/booking-options";
import { useActionMutation, useActionQuery } from "@agent-native/core/client/hooks";
import { Link, useSearchParams } from "react-router";

export const SITE_NAME = "Madhu Battu Counseling";
const PHONE = "9034006803";
const WHATSAPP_URL = `https://wa.me/91${PHONE}`;
const INSTAGRAM_URL =
  "https://www.instagram.com/jnv_school_counsellor?utm_source=ig_web_button_share_sheet&mdxt=ZDNlZDc0MzIxNw==";
const EMAIL = "madhunature903@gmail.com";

// Swap these src values for final photos.
const HERO_IMAGE = {
  src: "https://cdn.builder.io/api/v1/image/assets%2F7d0f8359d14f41539af0367d8eb302e3%2F96f6f1b6dc694d4e8307d84b4571f136?format=webp&width=800&height=1200",
  alt: "Counselor with a client during an online counseling session",
};
const ABOUT_IMAGE = {
  src: "https://placehold.co/800x1000/e6efec/2f5d55?text=Madhu+Battu",
  alt: "Portrait of Madhu Battu",
};

const NAV_LINKS = [
  { label: "Home", href: "/", icon: IconHome },
  { label: "About", href: "/about", icon: IconUser },
  { label: "Services", href: "/services", icon: IconBriefcase },
  { label: "Testimonials", href: "/testimonials", icon: IconStar },
  { label: "FAQ", href: "/faq", icon: IconQuestionMark },
  { label: "Contact Us", href: "/contact", icon: IconMail },
];

const SERVICES = [
  {
    icon: IconBrain,
    slug: "cognitive-behavioral-therapy",
    title: "Cognitive Behavioral Therapy (CBT)",
    body: "Identify and reframe negative thought patterns and emotional blocks using proven, evidence-based psychological techniques.",
    helpsWith: ["Unhelpful thought patterns", "Anxiety and persistent worry", "Low confidence and self-criticism", "Habits that keep you stuck"],
  },
  {
    icon: IconTarget,
    slug: "career-guidance",
    title: "Career Guidance & Counseling",
    body: "Personalized direction for students and professionals to align skills, passions, and goals with the right career pathway.",
    helpsWith: ["Choosing a course or career path", "Clarifying skills, interests, and strengths", "Career changes and transitions", "Setting goals and a realistic plan"],
  },
  {
    icon: IconLeaf,
    slug: "mental-health-stress-management",
    title: "Mental Health & Stress Management",
    body: "Effective strategies to manage anxiety, depression, burnout, and everyday life stressors to regain peace of mind.",
    helpsWith: ["Anxiety and feeling overwhelmed", "Burnout and exhaustion", "Low mood and lost motivation", "Coping with everyday pressures"],
  },
  {
    icon: IconHeartHandshake,
    slug: "marital-relationship-counseling",
    title: "Marital & Relationship Counseling",
    body: "Rebuild trust, improve communication, and resolve conflicts to foster a healthy, fulfilling partnership.",
    helpsWith: ["Communication breakdowns", "Trust issues and repeated conflicts", "Emotional distance between partners", "Planning together for a healthier relationship"],
  },
  {
    icon: IconUsers,
    slug: "family-wellness-dynamics",
    title: "Family Wellness & Dynamics",
    body: "Strengthen family bonds, navigate generational gaps, and build a supportive home environment.",
    helpsWith: ["Conflict between family members", "Generational differences and expectations", "Parenting and communication concerns", "Creating a more supportive home"],
  },
  {
    icon: IconSeedling,
    slug: "personal-growth-mindset-coaching",
    title: "Personal Growth & Mindset Coaching",
    body: "Boost self-esteem, improve emotional regulation, and unlock your true potential.",
    helpsWith: ["Low self-esteem", "Managing emotions and reactions", "Building confidence and self-belief", "Defining personal goals and values"],
  },
  {
    icon: IconMoodSad,
    slug: "depression-counseling",
    title: "Depression Counseling",
    body: "A supportive, structured space to understand low mood and build practical steps toward feeling like yourself again.",
    helpsWith: ["Persistent low mood or loss of interest", "Feeling stuck, tired, or withdrawn", "Negative thinking about yourself or the future", "Small, steady steps back to daily life"],
  },
  {
    icon: IconWind,
    slug: "stress-management",
    title: "Stress Management",
    body: "Learn to recognize stress triggers and apply practical techniques to calm your mind and manage pressure.",
    helpsWith: ["Identifying stress triggers", "Relaxation and calming techniques", "Managing pressure at work or school", "Preventing stress from building up"],
  },
  {
    icon: IconActivity,
    slug: "mood-swings",
    title: "Mood Swings",
    body: "Understand the patterns behind sudden shifts in mood and develop tools to bring more balance and stability.",
    helpsWith: ["Sudden shifts in mood", "Understanding emotional triggers", "Steadier routines and coping tools", "Talking about mood changes with people close to you"],
  },
];

export function findService(slug: string) {
  return SERVICES.find((service) => service.slug === slug);
}

const PRICING_PLANS = [
  {
    icon: IconMessageCircle,
    title: "Chat Session",
    price: "₹300",
    body: "A 30-minute counseling session over text chat.",
  },
  {
    icon: IconPhone,
    title: "Voice Call",
    price: "₹600",
    body: "A 30-minute counseling session over a voice call.",
  },
  {
    icon: IconVideo,
    title: "Video Call",
    price: "₹1,000",
    body: "A 30-minute face-to-face counseling session over video.",
  },
  {
    icon: IconHeartHandshake,
    title: "Couple Counseling",
    price: "₹1,500",
    body: "A joint counseling session for partners to work through concerns together.",
  },
];

const WHY_POINTS = [
  {
    icon: IconCheck,
    title: "Professional Expertise",
    body: "Backed by advanced academic qualifications (M.Sc. Psychology) and specialized CBT training.",
  },
  {
    icon: IconLock,
    title: "100% Confidentiality",
    body: "A private, safe, and confidential environment for every discussion.",
  },
  {
    icon: IconTarget,
    title: "Tailored Approach",
    body: "Customized therapy plans tailored to your specific needs and goals.",
  },
  {
    icon: IconCalendarEvent,
    title: "Flexible Sessions",
    body: "Available for both online (video calls) and in-person sessions.",
  },
];

const STEPS = [
  {
    title: "Reach out",
    body: "Send a request with a few details about what you are going through.",
  },
  {
    title: "Consult",
    body: "We talk through your concerns, goals, and what you have already tried.",
  },
  {
    title: "Plan together",
    body: "We agree on a personal approach and a schedule that works for you.",
  },
];

const FAQS = [
  {
    question: "Who is Madhu Battu?",
    answer:
      "I am a qualified psychologist with an M.Sc. in Psychology. I work with individuals, couples, and families, and my practice focuses on Cognitive Behavioral Therapy, combined with warmth and patience. My aim is to help you find clarity, steadier emotions, and a path forward that fits your life.",
  },
  {
    question: "What is Cognitive Behavioral Therapy (CBT)?",
    answer:
      "CBT is a structured, evidence-based approach that looks at how thoughts, feelings, and behaviors affect one another. Together we identify unhelpful patterns and practice more balanced ways of responding, both in sessions and in daily life.",
  },
  {
    question: "Is what I share kept confidential?",
    answer:
      "Yes. What we discuss stays private. The exceptions are rare: situations where the law requires disclosure, or where someone's safety is seriously at risk. Wherever possible, I would talk with you about any such step before taking it.",
  },
  {
    question: "What happens in the first session?",
    answer:
      "We start with what brought you in, what you hope to change, and what you have already tried. You do not need to share everything at once. We finish by agreeing on next steps together.",
  },
  {
    question: "Do you offer online sessions?",
    answer:
      "Yes. Sessions are available by video call or in person, so you can choose the format that feels most comfortable and convenient.",
  },
  {
    question: "Do you work with relationship and family concerns?",
    answer:
      "Yes. I offer counseling for couples and families as well as individuals. Sessions are shaped around the people who attend and the specific concerns they bring.",
  },
  {
    question: "How do I book a session?",
    answer:
      "Use the booking form on this page, or reach out by phone or WhatsApp. I will reply to confirm a time that works for you.",
  },
  {
    question: "Is this website a crisis service?",
    answer:
      "No. If you are in immediate danger or experiencing a crisis, please contact your local emergency number or a crisis helpline right away.",
  },
];

const SERVICE_OPTIONS = [
  ...SERVICES.map((service) => service.title),
  "Not sure yet",
];

export function Logo() {
  return (
    <div className="flex items-center gap-2.5">
      <img
        src="https://cdn.builder.io/api/v1/image/assets%2F7d0f8359d14f41539af0367d8eb302e3%2Fe70defec495b41f390f9b7b616bbab2b?format=webp&width=800&height=1200"
        alt={SITE_NAME}
        className="size-9 rounded-full object-cover"
      />
      <span className="text-[15px] font-semibold tracking-tight">MADHU BATTU</span>
    </div>
  );
}

function SectionHeading({ eyebrow, title }: { eyebrow: string; title: string }) {
  return (
    <div className="max-w-2xl">
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary">
        {eyebrow}
      </p>
      <h2 className="mt-3 text-3xl font-semibold tracking-tight md:text-4xl">
        {title}
      </h2>
    </div>
  );
}

export function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-30 border-b border-border/70 bg-background/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-6 px-6 py-3.5">
        <Link to="/" aria-label={SITE_NAME}>
          <Logo />
        </Link>
        <nav className="hidden items-center gap-6 text-sm text-muted-foreground lg:flex">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1 text-xs font-semibold uppercase tracking-[0.12em] text-primary">
            <IconCompass className="size-3.5" stroke={2} />
            Explore
          </span>
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              to={link.href}
              className="inline-flex items-center gap-1.5 transition-colors hover:text-foreground"
            >
              <link.icon className="size-4" stroke={1.75} />
              {link.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Chat on WhatsApp"
            className="inline-flex size-9 items-center justify-center rounded-md border border-border text-foreground transition-colors hover:bg-muted"
          >
            <IconBrandWhatsapp className="size-5" stroke={1.75} />
          </a>
          <a
            href={INSTAGRAM_URL}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Follow us on Instagram"
            className="inline-flex size-9 items-center justify-center rounded-md border border-border text-foreground transition-colors hover:bg-muted"
          >
            <IconBrandInstagram className="size-5" stroke={1.75} />
          </a>
          <Button asChild size="sm">
            <Link to="/contact#book">Book a Session</Link>
          </Button>
          <button
            type="button"
            aria-label={menuOpen ? "Close menu" : "Open menu"}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((open) => !open)}
            className="inline-flex size-9 items-center justify-center rounded-md border border-border text-foreground lg:hidden"
          >
            {menuOpen ? <IconX className="size-5" /> : <IconMenu2 className="size-5" />}
          </button>
        </div>
      </div>
      {menuOpen && (
        <nav className="border-t border-border/70 bg-background px-6 py-3 lg:hidden">
          <p className="mx-auto flex max-w-6xl items-center gap-2 px-3 pb-2 pt-1 text-xs font-semibold uppercase tracking-[0.12em] text-primary">
            <IconCompass className="size-4" stroke={2} />
            Explore
          </p>
          <ul className="mx-auto grid max-w-6xl gap-1">
            {NAV_LINKS.map((link) => (
              <li key={link.href}>
                <Link
                  to={link.href}
                  onClick={() => setMenuOpen(false)}
                  className="flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground"
                >
                  <link.icon className="size-4" stroke={1.75} />
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      )}
    </header>
  );
}

export function Hero() {
  return (
    <section id="home" className="relative overflow-hidden border-b border-border/60">
      <div className="mx-auto grid max-w-6xl items-center gap-14 px-6 py-20 md:py-28 lg:grid-cols-[1.15fr_1fr]">
        <div>
          <p className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-muted-foreground">
            <IconLock className="size-3.5 text-primary" stroke={2} />
            Private and confidential counseling
          </p>
          <h1 className="mt-6 text-4xl font-semibold leading-[1.1] tracking-tight md:text-6xl">
            Empowering Minds, Restoring Balance, Enriching Lives.
          </h1>
          <p className="mt-6 max-w-xl text-lg leading-relaxed text-muted-foreground">
            Professional, compassionate, and 100% confidential psychological
            counseling tailored to help you navigate life's challenges.
          </p>
          <div className="mt-9 flex flex-wrap items-center gap-3">
            <Button asChild size="lg">
              <Link to="/contact#book">Book a Consultation</Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link to="/contact">Schedule a Call</Link>
            </Button>
          </div>
          <p className="mt-5 text-sm text-muted-foreground">Online video or in-person sessions, arranged around your schedule.</p>
        </div>

        <div className="rounded-2xl border border-border bg-card p-7 shadow-sm md:p-8">
          <p className="text-sm font-semibold">What to expect</p>
          <ol className="mt-6 space-y-6">
            {STEPS.map((step, index) => (
              <li key={step.title} className="flex gap-4">
                <span className="flex size-8 shrink-0 items-center justify-center rounded-full bg-primary text-sm font-semibold text-primary-foreground">
                  {index + 1}
                </span>
                <div>
                  <p className="font-medium">{step.title}</p>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </div>
      <div className="mx-auto max-w-6xl px-6 pb-20 md:pb-28">
        <img
          src={HERO_IMAGE.src}
          alt={HERO_IMAGE.alt}
          className="aspect-[12/5] w-full rounded-2xl border border-border object-cover"
        />
      </div>
    </section>
  );
}

const DEFAULT_SESSION_PHOTOS = [
  { id: "default-1", src: "/images/counseling/tile-1.jpg", alt: "Counselor leading an online session from a home office" },
  { id: "default-2", src: "/images/counseling/tile-2.jpg", alt: "Client sharing during a video session from a cozy sofa" },
  { id: "default-5", src: "/images/counseling/tile-5.jpg", alt: "Counselor taking notes during a face-to-face session" },
];

const MAX_PHOTO_BYTES = 1_400_000;

function readAsDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

export function SessionGallery() {
  const { data: photos } = useActionQuery("list-site-photos");
  const visiblePhotos = photos && photos.length > 0 ? photos : DEFAULT_SESSION_PHOTOS;

  return (
    <section className="mx-auto max-w-6xl px-6 pb-24">
      <div className="grid gap-5 md:grid-cols-3">
        {visiblePhotos.map((photo) => (
          <img
            key={photo.id}
            src={photo.src}
            alt={photo.alt}
            className="aspect-[16/9] w-full rounded-2xl border border-border object-cover"
          />
        ))}
      </div>
    </section>
  );
}

function AdminTools({ passcode }: { passcode: string }) {
  const { data: photos } = useActionQuery("list-site-photos");
  const addPhoto = useActionMutation("create-site-photo");
  const deletePhoto = useActionMutation("delete-site-photo", { method: "DELETE" });
  const addReview = useActionMutation("create-site-review");
  const loadRequests = useActionMutation("list-booking-requests");
  const loadReviews = useActionMutation("list-all-site-reviews");
  const setReviewStatus = useActionMutation("update-site-review-status");
  const [photoSrc, setPhotoSrc] = useState("");
  const [photoError, setPhotoError] = useState("");

  useEffect(() => {
    loadRequests.mutate({ passcode });
    loadReviews.mutate({ passcode });
  }, [passcode]);

  function changeReviewStatus(id: string, status: "approved" | "rejected") {
    setReviewStatus.mutate(
      { passcode, id, status },
      { onSuccess: () => loadReviews.mutate({ passcode }) },
    );
  }

  async function handleFileChange(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    setPhotoSrc("");
    setPhotoError("");
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setPhotoError("Choose an image file.");
      return;
    }
    if (file.size > MAX_PHOTO_BYTES) {
      setPhotoError("Image must be under 1.4 MB. Compress it and try again.");
      return;
    }
    setPhotoSrc(await readAsDataUrl(file));
  }

  function handleAddPhoto(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!photoSrc) return;
    const form = event.currentTarget;
    const alt = String(new FormData(form).get("alt") ?? "");
    addPhoto.mutate(
      { passcode, src: photoSrc, alt },
      {
        onSuccess: () => {
          form.reset();
          setPhotoSrc("");
        },
      },
    );
  }

  function handleAddReview(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    addReview.mutate(
      {
        passcode,
        clientName: String(data.get("clientName") ?? ""),
        body: String(data.get("body") ?? ""),
      },
      { onSuccess: () => form.reset() },
    );
  }

  return (
    <div className="mt-6 grid gap-10 rounded-2xl border border-border bg-card p-7 shadow-sm lg:grid-cols-2">
      <div>
        <h3 className="text-lg font-semibold">Photos</h3>
        <form onSubmit={handleAddPhoto} className="mt-5 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="photoFile">Image file (under 1.4 MB)</Label>
            <Input id="photoFile" type="file" accept="image/*" onChange={handleFileChange} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="photoAlt">Description</Label>
            <Input id="photoAlt" name="alt" required />
          </div>
          <Button type="submit" disabled={!photoSrc || addPhoto.isPending}>
            <IconPlus className="size-4" /> Add photo
          </Button>
          {photoError && <p className="text-sm text-destructive">{photoError}</p>}
          {addPhoto.isError && (
            <p className="text-sm text-destructive">Could not add the photo. Check the passcode and try again.</p>
          )}
        </form>
        <ul className="mt-6 grid grid-cols-2 gap-4">
          {(photos ?? []).map((photo) => (
            <li key={photo.id} className="relative">
              <img src={photo.src} alt={photo.alt} className="aspect-[16/9] w-full rounded-lg border border-border object-cover" />
              <Button
                type="button"
                size="icon"
                variant="destructive"
                className="absolute right-2 top-2 size-8"
                aria-label="Delete photo"
                disabled={deletePhoto.isPending}
                onClick={() => deletePhoto.mutate({ passcode, id: photo.id })}
              >
                <IconTrash className="size-4" />
              </Button>
            </li>
          ))}
        </ul>
      </div>

      <div>
        <h3 className="text-lg font-semibold">Add a review</h3>
        <form onSubmit={handleAddReview} className="mt-5 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="reviewName">Client name or initials</Label>
            <Input id="reviewName" name="clientName" required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="reviewBody">Review</Label>
            <textarea
              id="reviewBody"
              name="body"
              rows={5}
              required
              className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm shadow-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </div>
          <Button type="submit" disabled={addReview.isPending}>
            <IconPlus className="size-4" /> Add review
          </Button>
          {addReview.isSuccess && <p className="text-sm text-primary">Review added.</p>}
          {addReview.isError && (
            <p className="text-sm text-destructive">Could not add the review. Check the passcode and try again.</p>
          )}
        </form>
      </div>

      <div className="lg:col-span-2">
        <h3 className="text-lg font-semibold">Reviews</h3>
        {loadReviews.isSuccess && loadReviews.data.length === 0 && (
          <p className="mt-4 text-sm text-muted-foreground">No reviews yet.</p>
        )}
        <ul className="mt-5 divide-y divide-border">
          {(loadReviews.data ?? []).map((review) => (
            <li key={review.id} className="grid gap-3 py-4 text-sm sm:grid-cols-[1fr_auto] sm:items-start">
              <div className="space-y-1">
                <p className="font-medium">
                  {review.clientName} <span className="ml-2 text-xs uppercase text-muted-foreground">{review.status}</span>
                </p>
                <p className="text-muted-foreground">{review.body}</p>
              </div>
              <div className="flex gap-2">
                {review.status !== "approved" && (
                  <Button
                    type="button"
                    size="sm"
                    disabled={setReviewStatus.isPending}
                    onClick={() => changeReviewStatus(review.id, "approved")}
                  >
                    Approve
                  </Button>
                )}
                {review.status !== "rejected" && (
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    disabled={setReviewStatus.isPending}
                    onClick={() => changeReviewStatus(review.id, "rejected")}
                  >
                    Reject
                  </Button>
                )}
              </div>
            </li>
          ))}
        </ul>
      </div>

      <div className="lg:col-span-2">
        <h3 className="text-lg font-semibold">Visitor requests</h3>
        {loadRequests.isError && (
          <p className="mt-4 text-sm text-destructive">Could not load requests.</p>
        )}
        {loadRequests.isSuccess && loadRequests.data.length === 0 && (
          <p className="mt-4 text-sm text-muted-foreground">No requests yet.</p>
        )}
        <ul className="mt-5 divide-y divide-border">
          {(loadRequests.data ?? []).map((request) => (
            <li key={request.id} className="grid gap-1 py-4 text-sm sm:grid-cols-[1fr_1fr_1fr]">
              <span className="font-medium">{request.fullName}</span>
              <span className="text-muted-foreground">{request.contact}</span>
              <span className="text-muted-foreground">{request.service}</span>
              <span className="text-muted-foreground">
                {SESSION_TYPES.find((type) => type.id === request.sessionType)?.label ?? "Not specified"}
                {request.amount > 0 && ` · ${formatRupees(request.amount)}`}
              </span>
              <span className="text-muted-foreground">
                {PAYMENT_OPTIONS.find((option) => option.id === request.paymentOption)?.label ?? "No payment"}
                {request.paymentScreenshotUrl && (
                  <>
                    {" · "}
                    <a href={request.paymentScreenshotUrl} target="_blank" rel="noreferrer" className="underline hover:text-foreground">
                      View screenshot
                    </a>
                  </>
                )}
              </span>
              <span className="text-muted-foreground">{request.preferredSlot}</span>
              <span className="text-muted-foreground">{request.createdAt}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export function AdminPanel() {
  const [open, setOpen] = useState(false);
  const [adminPasscode, setAdminPasscode] = useState<string | null>(null);
  const verify = useActionMutation("verify-admin-passcode");

  function handleUnlock(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const passcode = String(new FormData(event.currentTarget).get("passcode") ?? "");
    verify.mutate(
      { passcode },
      { onSuccess: () => setAdminPasscode(passcode) },
    );
  }

  return (
    <section className="mx-auto max-w-6xl px-6 pb-20">
      <div className="flex justify-end">
        <Button variant="outline" size="sm" onClick={() => setOpen((value) => !value)}>
          <IconLock className="size-4" />
          {adminPasscode ? "Admin tools" : "Admin lock"}
        </Button>
      </div>
      {open && adminPasscode && <AdminTools passcode={adminPasscode} />}
      {open && !adminPasscode && (
        <form onSubmit={handleUnlock} className="mt-6 flex max-w-sm flex-col gap-3 rounded-2xl border border-border bg-card p-7 shadow-sm">
          <Label htmlFor="adminPasscode">Admin passcode</Label>
          <Input id="adminPasscode" name="passcode" type="password" required />
          <Button type="submit" disabled={verify.isPending}>
            Unlock
          </Button>
          {verify.isError && <p className="text-sm text-destructive">Incorrect passcode.</p>}
        </form>
      )}
    </section>
  );
}

export function About() {
  return (
    <section id="about" className="mx-auto max-w-6xl px-6 py-24">
      <div className="grid gap-14 lg:grid-cols-[1fr_1.2fr]">
        <div>
          <img
            src={ABOUT_IMAGE.src}
            alt={ABOUT_IMAGE.alt}
            className="mb-10 aspect-[4/5] w-full max-w-sm rounded-2xl border border-border object-cover"
          />
          <SectionHeading eyebrow="About" title="Welcome, I am Madhu Battu." />
          <ul className="mt-8 space-y-3 text-sm text-muted-foreground">
            <li className="flex items-center gap-3">
              <IconCheck className="size-4 text-primary" stroke={2.25} />
              M.Sc. in Psychology
            </li>
            <li className="flex items-center gap-3">
              <IconCheck className="size-4 text-primary" stroke={2.25} />
              Specialized training in Cognitive Behavioral Therapy
            </li>
            <li className="flex items-center gap-3">
              <IconCheck className="size-4 text-primary" stroke={2.25} />
              Online and in-person sessions
            </li>
          </ul>
        </div>
        <div className="space-y-5 text-[17px] leading-relaxed text-muted-foreground">
          <p>
            As a qualified Psychologist holding an M.Sc. in Psychology, I am
            dedicated to helping individuals, couples, and families achieve
            emotional well-being and personal growth. Specializing in Cognitive
            Behavioral Therapy (CBT), my approach combines evidence-based
            psychological tools with deep empathy to create a safe,
            non-judgmental space for healing.
          </p>
          <p>
            Whether you are facing career decisions, relationship issues, or
            daily stress, I am here to support your journey toward clarity and
            resilience.
          </p>
        </div>
      </div>
    </section>
  );
}

export function Services() {
  return (
    <section id="services" className="border-y border-border/60 bg-secondary/40 py-24">
      <div className="mx-auto max-w-6xl px-6">
        <SectionHeading eyebrow="Services" title="Specialized Counseling Services" />
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((service) => (
            <Link
              key={service.slug}
              to={`/services/${service.slug}`}
              className="group rounded-xl border border-border bg-card p-7 transition-colors hover:border-primary/40"
            >
              <span className="flex size-11 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <service.icon className="size-5" stroke={1.75} />
              </span>
              <h3 className="mt-5 font-semibold">{service.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{service.body}</p>
              <span className="mt-5 inline-block text-sm font-medium text-primary group-hover:underline">View details</span>
            </Link>
          ))}
        </div>

        <div className="mt-20">
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary">Session fees</p>
          <h3 className="mt-3 text-2xl font-semibold tracking-tight md:text-3xl">Every session is 30 minutes</h3>
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {PRICING_PLANS.map((plan) => (
              <div key={plan.title} className="flex flex-col rounded-xl border border-border bg-card p-7">
                <span className="flex size-11 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <plan.icon className="size-5" stroke={1.75} />
                </span>
                <h4 className="mt-5 font-semibold">{plan.title}</h4>
                <p className="mt-2 text-2xl font-semibold tracking-tight text-primary">{plan.price}</p>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{plan.body}</p>
              </div>
            ))}
          </div>
          <div className="mt-5 flex flex-col gap-4 rounded-xl border border-primary/40 bg-card p-7 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-start gap-4">
              <span className="flex size-11 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <IconGift className="size-5" stroke={1.75} />
              </span>
              <div>
                <h4 className="font-semibold">Free trial session</h4>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                  A short 3 to 5 minute introduction so you can get to know me before booking.
                </p>
              </div>
            </div>
            <Button asChild variant="outline">
              <Link to="/contact#book">Book a free trial</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}

export function ServiceDetail({ slug }: { slug: string }) {
  const service = findService(slug);
  const { data: reviews } = useActionQuery("list-site-reviews");
  const serviceReviews = service ? (reviews ?? []).filter((review) => review.service === service.title) : [];

  if (!service) {
    return (
      <section className="mx-auto max-w-3xl px-6 py-24 text-center">
        <h1 className="text-3xl font-semibold tracking-tight">Service not found</h1>
        <Button asChild variant="outline" className="mt-8">
          <Link to="/services">Back to services</Link>
        </Button>
      </section>
    );
  }

  return (
    <section className="mx-auto max-w-4xl px-6 py-24">
      <Link to="/services" className="text-sm text-muted-foreground hover:text-foreground">
        Back to services
      </Link>
      <span className="mt-8 flex size-11 items-center justify-center rounded-lg bg-primary/10 text-primary">
        <service.icon className="size-5" stroke={1.75} />
      </span>
      <p className="mt-6 text-xs font-semibold uppercase tracking-[0.18em] text-primary">Service</p>
      <h1 className="mt-3 text-3xl font-semibold tracking-tight md:text-4xl">{service.title}</h1>
      <p className="mt-6 max-w-2xl text-[15px] leading-relaxed text-muted-foreground">{service.body}</p>

      <h2 className="mt-14 text-xl font-semibold">What we can work on</h2>
      <ul className="mt-6 grid gap-4 sm:grid-cols-2">
        {service.helpsWith.map((item) => (
          <li key={item} className="flex gap-3 text-[15px] text-muted-foreground">
            <IconCheck className="mt-0.5 size-4 shrink-0 text-primary" stroke={2} />
            <span>{item}</span>
          </li>
        ))}
      </ul>

      {serviceReviews.length > 0 && (
        <div className="mt-14">
          <h2 className="text-xl font-semibold">What clients say</h2>
          <div className="mt-6 grid gap-6 md:grid-cols-2">
            {serviceReviews.map((review) => (
              <figure key={review.id} className="rounded-2xl border border-border bg-card p-7 shadow-sm">
                <blockquote className="text-[15px] leading-relaxed text-muted-foreground">“{review.body}”</blockquote>
                <figcaption className="mt-4 text-sm font-semibold">{review.clientName}</figcaption>
              </figure>
            ))}
          </div>
        </div>
      )}

      <div className="mt-14 rounded-2xl border border-border bg-card p-7 shadow-sm md:p-9">
        <h2 className="text-xl font-semibold">Book a Session</h2>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
          Sessions are 30 minutes and available by chat, voice call, or video call. {service.title} is already selected in the booking form.
        </p>
        <Button asChild className="mt-6">
          <Link to={`/contact?service=${service.slug}#book`}>Book a Session</Link>
        </Button>
      </div>
    </section>
  );
}

export function Why() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-24">
      <SectionHeading eyebrow="Why choose us" title="Why Choose Madhu Battu Counseling?" />
      <div className="mt-14 grid gap-x-12 gap-y-10 sm:grid-cols-2">
        {WHY_POINTS.map((point) => (
          <div key={point.title} className="flex gap-4">
            <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <point.icon className="size-5" stroke={1.75} />
            </span>
            <div>
              <h3 className="font-semibold">{point.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{point.body}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export function Credentials() {
  return (
    <section className="mx-auto max-w-6xl px-6 pb-4">
      <div className="grid gap-4 rounded-2xl border border-border bg-card p-7 sm:grid-cols-3">
        {[
          { icon: IconCheck, text: "M.Sc. in Psychology" },
          { icon: IconBrain, text: "Specialized CBT training" },
          { icon: IconLock, text: "100% confidential sessions" },
        ].map((item) => (
          <p key={item.text} className="flex items-center gap-3 text-sm font-medium">
            <item.icon className="size-5 shrink-0 text-primary" stroke={1.75} />
            {item.text}
          </p>
        ))}
      </div>
    </section>
  );
}

export function HomeSessionFees() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-24">
      <SectionHeading eyebrow="Session fees" title="Every session is 30 minutes" />
      <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {PRICING_PLANS.map((plan) => (
          <div key={plan.title} className="flex flex-col rounded-xl border border-border bg-card p-7">
            <span className="flex size-11 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <plan.icon className="size-5" stroke={1.75} />
            </span>
            <h3 className="mt-5 font-semibold">{plan.title}</h3>
            <p className="mt-2 text-2xl font-semibold tracking-tight text-primary">{plan.price}</p>
          </div>
        ))}
      </div>
      <div className="mt-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm text-muted-foreground">
          Not sure yet? Start with a free 3 to 5 minute introduction session.
        </p>
        <Button asChild variant="outline">
          <Link to="/contact#book">Book a free trial</Link>
        </Button>
      </div>
    </section>
  );
}

export function CrisisNotice() {
  return (
    <section className="mx-auto max-w-6xl px-6 pb-24">
      <div className="flex gap-4 rounded-2xl border border-border bg-secondary/40 p-7">
        <IconPhone className="mt-0.5 size-5 shrink-0 text-primary" stroke={1.75} />
        <p className="text-sm leading-relaxed text-muted-foreground">
          This website is not a crisis service. If you are in immediate danger or experiencing a crisis, contact your local
          emergency number or a crisis helpline right away.
        </p>
      </div>
    </section>
  );
}

export function Testimonials() {
  const { data: reviews } = useActionQuery("list-site-reviews");

  return (
    <section id="testimonials" className="border-y border-border/60 bg-secondary/40 py-24">
      <div className="mx-auto max-w-6xl px-6">
        <SectionHeading eyebrow="Testimonials" title="What clients say" />
        {reviews && reviews.length > 0 ? (
          <div className="mt-14 grid gap-6 md:grid-cols-2">
            {reviews.map((review) => (
              <figure key={review.id} className="rounded-2xl border border-border bg-card p-8 shadow-sm">
                <blockquote className="text-[15px] leading-relaxed text-muted-foreground">
                  “{review.body}”
                </blockquote>
                <figcaption className="mt-5 text-sm font-semibold">
                  {review.clientName}
                  {review.service && (
                    <span className="block text-xs font-normal text-muted-foreground">{review.service}</span>
                  )}
                </figcaption>
              </figure>
            ))}
          </div>
        ) : (
          <div className="mt-14 rounded-xl border border-dashed border-border bg-card p-10 text-center">
            <IconMessageCircle className="mx-auto size-8 text-muted-foreground" stroke={1.5} />
            <p className="mt-4 text-sm text-muted-foreground">
              Client reviews will appear here once they have been approved.
            </p>
          </div>
        )}
      </div>
    </section>
  );
}

export function ReviewSubmission() {
  const submitReview = useActionMutation("submit-site-review");

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    submitReview.mutate(
      {
        clientName: String(data.get("clientName") ?? ""),
        service: String(data.get("service") ?? ""),
        body: String(data.get("body") ?? ""),
      },
      { onSuccess: () => form.reset() },
    );
  }

  return (
    <section id="share-review" className="mx-auto max-w-3xl px-6 py-24">
      <SectionHeading eyebrow="Feedback" title="Share your experience" />
      <form onSubmit={handleSubmit} className="mt-10 space-y-5 rounded-2xl border border-border bg-card p-7 shadow-sm">
        <div className="space-y-2">
          <Label htmlFor="publicReviewName">Name or initials</Label>
          <Input id="publicReviewName" name="clientName" required maxLength={120} />
        </div>
        <div className="space-y-2">
          <Label htmlFor="publicReviewService">Service taken</Label>
          <select
            id="publicReviewService"
            name="service"
            required
            defaultValue=""
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <option value="" disabled>
              Select a service
            </option>
            {SERVICE_OPTIONS.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="publicReviewBody">Your review</Label>
          <textarea
            id="publicReviewBody"
            name="body"
            rows={5}
            required
            maxLength={2000}
            className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm shadow-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          />
        </div>
        <div className="flex flex-wrap items-center gap-4">
          <Button type="submit" disabled={submitReview.isPending}>
            Submit review
          </Button>
          {submitReview.isSuccess && (
            <p className="text-sm text-primary">Thank you. Your review will appear once it is approved.</p>
          )}
          {submitReview.isError && (
            <p className="text-sm text-destructive">Something went wrong. Please try again.</p>
          )}
        </div>
      </form>
    </section>
  );
}

export function Faq() {
  return (
    <section id="faq" className="mx-auto max-w-4xl px-6 py-24">
      <SectionHeading eyebrow="Questions" title="Frequently asked questions" />
      <Accordion type="single" collapsible className="mt-12">
        {FAQS.map((faq) => (
          <AccordionItem key={faq.question} value={faq.question}>
            <AccordionTrigger className="text-left text-[15px] font-medium">
              {faq.question}
            </AccordionTrigger>
            <AccordionContent className="text-sm leading-relaxed text-muted-foreground">
              {faq.answer}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </section>
  );
}

const PAYMENT_QR_SRC = "/images/payment-qr.png";

const selectClassName =
  "flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-60";

async function uploadPaymentScreenshot(file: File): Promise<string> {
  const body = new FormData();
  body.append("file", file);
  const response = await fetch("/_agent-native/file-upload", { method: "POST", body });
  if (!response.ok) throw new Error("Upload failed");
  const result = (await response.json()) as { url?: string };
  if (!result.url) throw new Error("Upload failed");
  return result.url;
}

function defaultSessionType(service: string): SessionTypeId | "" {
  const options = allowedSessionTypes(service);
  return options.length === 1 ? options[0] : "";
}

function BookingForm() {
  const createRequest = useActionMutation("create-booking-request");
  const [searchParams] = useSearchParams();
  const presetService = findService(searchParams.get("service") ?? "")?.title ?? "";
  const [service, setService] = useState(presetService);
  const [sessionType, setSessionType] = useState<SessionTypeId | "">(defaultSessionType(presetService));
  const [paymentOption, setPaymentOption] = useState<PaymentOptionId | "">("");
  const [screenshot, setScreenshot] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const isCoupleService = service === COUPLE_SERVICE;
  const sessionOptions = service ? allowedSessionTypes(service) : [];
  const amount = service && sessionType ? sessionAmount(service, sessionType) : 0;
  const needsPayment = amount > 0;
  const isAdvance = needsPayment && paymentOption === "advance";

  function handleServiceChange(value: string) {
    setService(value);
    setSessionType(defaultSessionType(value));
    setPaymentOption("");
    setScreenshot(null);
    setUploadError(null);
  }

  function handleSessionTypeChange(value: SessionTypeId) {
    setSessionType(value);
    setPaymentOption("");
    setScreenshot(null);
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    setUploadError(null);

    let paymentScreenshotUrl: string | undefined;
    if (isAdvance) {
      if (!screenshot) {
        setUploadError("Upload a screenshot of your payment to continue.");
        return;
      }
      setIsUploading(true);
      try {
        paymentScreenshotUrl = await uploadPaymentScreenshot(screenshot);
      } catch {
        setUploadError("The screenshot could not be uploaded. Please try again.");
        return;
      } finally {
        setIsUploading(false);
      }
    }

    createRequest.mutate(
      {
        fullName: String(data.get("fullName") ?? ""),
        contact: String(data.get("contact") ?? ""),
        service,
        sessionType: sessionType as SessionTypeId,
        preferredSlot: String(data.get("preferredSlot") ?? ""),
        paymentOption: needsPayment && paymentOption ? paymentOption : undefined,
        paymentScreenshotUrl,
      },
      {
        onSuccess: () => {
          form.reset();
          handleServiceChange("");
        },
      },
    );
  }

  return (
    <form onSubmit={handleSubmit} className="mt-8 grid gap-5 sm:grid-cols-2">
      <div className="space-y-2">
        <Label htmlFor="fullName">Full Name</Label>
        <Input id="fullName" name="fullName" required />
      </div>
      <div className="space-y-2">
        <Label htmlFor="contact">Email / Phone Number</Label>
        <Input id="contact" name="contact" required />
      </div>
      <div className="space-y-2">
        <Label htmlFor="service">Service Required</Label>
        <select
          id="service"
          name="service"
          required
          value={service}
          onChange={(event) => handleServiceChange(event.target.value)}
          className={selectClassName}
        >
          <option value="" disabled>
            Select a service
          </option>
          {SERVICE_OPTIONS.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
        </select>
      </div>
      {service && (
        <div className="space-y-2">
          <Label htmlFor="sessionType">Session Type</Label>
          <select
            id="sessionType"
            required
            disabled={isCoupleService}
            value={sessionType}
            onChange={(event) => handleSessionTypeChange(event.target.value as SessionTypeId)}
            className={selectClassName}
          >
            {!isCoupleService && (
              <option value="" disabled>
                Select a session type
              </option>
            )}
            {SESSION_TYPES.filter((type) => sessionOptions.includes(type.id)).map((type) => {
              const typeAmount = sessionAmount(service, type.id);
              return (
                <option key={type.id} value={type.id}>
                  {typeAmount > 0 ? `${type.label} (${formatRupees(typeAmount)})` : type.label}
                </option>
              );
            })}
          </select>
          {isCoupleService && (
            <p className="text-xs text-muted-foreground">Couple counseling is held by video call only.</p>
          )}
        </div>
      )}
      <div className="space-y-2">
        <Label htmlFor="preferredSlot">Preferred Date &amp; Time Slot</Label>
        <Input id="preferredSlot" name="preferredSlot" type="datetime-local" required />
      </div>
      {needsPayment && (
        <fieldset className="space-y-3 sm:col-span-2">
          <legend className="text-sm font-medium">
            Payment for this session ({formatRupees(amount)})
          </legend>
          <div className="grid gap-3 sm:grid-cols-2">
            {PAYMENT_OPTIONS.map((option) => (
              <label
                key={option.id}
                className={`flex cursor-pointer items-center gap-3 rounded-lg border p-4 text-sm ${
                  paymentOption === option.id ? "border-primary bg-primary/5" : "border-border"
                }`}
              >
                <input
                  type="radio"
                  name="paymentOption"
                  value={option.id}
                  required
                  checked={paymentOption === option.id}
                  onChange={() => {
                    setPaymentOption(option.id);
                    setScreenshot(null);
                  }}
                />
                {option.label}
              </label>
            ))}
          </div>
        </fieldset>
      )}
      {isAdvance && (
        <div className="space-y-4 rounded-xl border border-border bg-secondary/40 p-5 sm:col-span-2">
          <p className="text-sm text-muted-foreground">
            Scan the QR code below to pay {formatRupees(amount)}, then upload a screenshot of the payment.
          </p>
          <img src={PAYMENT_QR_SRC} alt="Payment QR code" className="mx-auto w-56 rounded-lg bg-white p-3" />
          <div className="space-y-2">
            <Label htmlFor="paymentScreenshot">Payment screenshot</Label>
            <Input
              id="paymentScreenshot"
              type="file"
              accept="image/*"
              required
              onChange={(event) => setScreenshot(event.target.files?.[0] ?? null)}
            />
          </div>
        </div>
      )}
      <div className="flex flex-wrap items-center gap-4 sm:col-span-2">
        <Button type="submit" disabled={createRequest.isPending || isUploading}>
          {isUploading ? "Uploading screenshot..." : "Submit Request"}
        </Button>
        {createRequest.isSuccess && (
          <p className="text-sm text-primary">Thank you. Madhu will contact you to confirm your appointment.</p>
        )}
        {uploadError && <p className="text-sm text-destructive">{uploadError}</p>}
        {createRequest.isError && (
          <p className="text-sm text-destructive">
            {createRequest.error instanceof Error ? createRequest.error.message : "Something went wrong. Please try again."}
          </p>
        )}
      </div>
    </form>
  );
}

export function Contact() {
  const [searchParams] = useSearchParams();
  const serviceParam = searchParams.get("service") ?? "";

  return (
    <section id="contact" className="mx-auto max-w-6xl px-6 py-24">
      <div className="grid gap-14 lg:grid-cols-[1fr_1.1fr]">
        <div>
          <SectionHeading eyebrow="Contact" title="Take the first step toward a healthier, happier mind." />
          <div className="mt-10 space-y-5 text-[15px] text-muted-foreground">
            <p className="flex items-center gap-3">
              <IconPhone className="size-5 text-primary" stroke={1.75} />
              <span>
                Direct Phone / WhatsApp:{" "}
                <a href={`tel:${PHONE}`} className="hover:text-foreground">
                  {PHONE}
                </a>
              </span>
            </p>
            <p className="flex items-center gap-3">
              <IconMail className="size-5 text-primary" stroke={1.75} />
              <a href={`mailto:${EMAIL}`} className="hover:text-foreground">
                {EMAIL}
              </a>
            </p>
            <p className="flex items-center gap-3">
              <IconMapPin className="size-5 text-primary" stroke={1.75} />
              <span>Online sessions by video call, in-person sessions by arrangement</span>
            </p>
            <p className="flex items-center gap-3">
              <IconBrandInstagram className="size-5 text-primary" stroke={1.75} />
              <a href={INSTAGRAM_URL} target="_blank" rel="noopener noreferrer" className="hover:text-foreground">
                Instagram: @jnv_school_counsellor
              </a>
            </p>
          </div>
        </div>
        <div id="book" className="rounded-2xl border border-border bg-card p-7 shadow-sm md:p-9">
          <h3 className="text-xl font-semibold">Quick Booking Form</h3>
          <p className="mt-2 text-sm text-muted-foreground">
            Share your preferred time and I will confirm the appointment with you.
          </p>
          <BookingForm key={serviceParam} />
        </div>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-border bg-secondary/40">
      <div className="mx-auto grid max-w-6xl gap-10 px-6 py-14 md:grid-cols-3">
        <div>
          <Logo />
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted-foreground">
            Confidential psychological counseling for individuals, couples, and families.
          </p>
        </div>
        <div>
          <p className="text-sm font-semibold">Explore</p>
          <ul className="mt-4 space-y-2.5 text-sm text-muted-foreground">
            {NAV_LINKS.map((link) => (
              <li key={link.href}>
                <Link to={link.href} className="hover:text-foreground">
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <p className="text-sm font-semibold">Important</p>
          <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
            This website provides general information and is not an emergency service. If you are in crisis, contact your local emergency number or a crisis helpline.
          </p>
        </div>
      </div>
      <div className="border-t border-border">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-2 px-6 py-6 text-xs text-muted-foreground md:flex-row">
          <span>© {new Date().getFullYear()} {SITE_NAME}. All rights reserved.</span>
          <span>Your information is kept confidential.</span>
        </div>
      </div>
    </footer>
  );
}

export function FloatingActions() {
  const [assistantOpen, setAssistantOpen] = useState(false);

  return (
    <div className="fixed bottom-5 right-5 z-40 flex flex-col items-end gap-3">
      {assistantOpen && (
        <div className="w-72 rounded-2xl border border-border bg-card p-5 shadow-lg">
          <div className="flex items-center justify-between">
            <p className="text-sm font-semibold">How can I help?</p>
            <button
              type="button"
              onClick={() => setAssistantOpen(false)}
              aria-label="Close assistant"
              className="text-muted-foreground hover:text-foreground"
            >
              <IconX className="size-4" />
            </button>
          </div>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
            Choose a quick option below. For anything urgent, please contact your local emergency number.
          </p>
          <div className="mt-4 flex flex-col gap-2 text-sm">
            <Link to="/contact#book" onClick={() => setAssistantOpen(false)} className="rounded-lg border border-border px-3 py-2 hover:bg-muted">
              Book a session
            </Link>
            <Link to="/services" onClick={() => setAssistantOpen(false)} className="rounded-lg border border-border px-3 py-2 hover:bg-muted">
              View services
            </Link>
            <a href={`tel:${PHONE}`} className="rounded-lg border border-border px-3 py-2 hover:bg-muted">
              Call {PHONE}
            </a>
          </div>
        </div>
      )}
      <button
        type="button"
        onClick={() => setAssistantOpen((open) => !open)}
        aria-label="Open quick help"
        className="flex size-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg transition-transform hover:scale-105"
      >
        <IconRobot className="size-6" stroke={1.75} />
      </button>
      <a
        href={WHATSAPP_URL}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat on WhatsApp"
        className="flex size-12 items-center justify-center rounded-full bg-[#25D366] text-white shadow-lg transition-transform hover:scale-105"
      >
        <IconBrandWhatsapp className="size-6" stroke={1.75} />
      </a>
    </div>
  );
}
