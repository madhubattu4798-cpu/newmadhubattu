export const COUPLE_SERVICE = "Marital & Relationship Counseling";

export const SESSION_TYPES = [
  { id: "free-trial", label: "Free Trial", amount: 0 },
  { id: "chat", label: "Chat", amount: 300 },
  { id: "voice", label: "Voice Call", amount: 600 },
  { id: "video", label: "Video Call", amount: 1000 },
] as const;

export type SessionTypeId = (typeof SESSION_TYPES)[number]["id"];

export const SESSION_TYPE_IDS = SESSION_TYPES.map((type) => type.id) as [SessionTypeId, ...SessionTypeId[]];

export const PAYMENT_OPTIONS = [
  { id: "advance", label: "Pay in advance" },
  { id: "during-session", label: "Pay during session" },
] as const;

export type PaymentOptionId = (typeof PAYMENT_OPTIONS)[number]["id"];

export const PAYMENT_OPTION_IDS = PAYMENT_OPTIONS.map((option) => option.id) as [PaymentOptionId, ...PaymentOptionId[]];

const COUPLE_AMOUNT = 1500;

export function allowedSessionTypes(service: string): SessionTypeId[] {
  if (service === COUPLE_SERVICE) return ["video"];
  return SESSION_TYPES.map((type) => type.id);
}

export function sessionAmount(service: string, sessionType: SessionTypeId): number {
  if (service === COUPLE_SERVICE) return COUPLE_AMOUNT;
  return SESSION_TYPES.find((type) => type.id === sessionType)?.amount ?? 0;
}

export function formatRupees(amount: number): string {
  return `₹${amount.toLocaleString("en-IN")}`;
}
