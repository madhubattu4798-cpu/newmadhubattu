import { timingSafeEqual } from "node:crypto";

import { fail } from "@agent-native/core/action";

export function assertAdminPasscode(passcode: string) {
  const expected = process.env.ADMIN_PASSCODE;
  if (!expected) throw new Error("Admin passcode is not configured");
  const given = Buffer.from(passcode);
  const actual = Buffer.from(expected);
  if (given.length !== actual.length || !timingSafeEqual(given, actual)) {
    fail("Invalid passcode", { errorCode: "invalid_passcode", statusCode: 401 });
  }
}
