import { spawnSync } from "node:child_process";

// Vercel's Git builds set VERCEL=1. Select Nitro's Vercel output format
// automatically, while respecting an explicitly supplied preset (e.g. Netlify).
if (process.env.VERCEL === "1" && !process.env.NITRO_PRESET) {
  process.env.NITRO_PRESET = "vercel";
}

const isWindows = process.platform === "win32";
const result = spawnSync("pnpm", ["exec", "agent-native", "build"], {
  stdio: "inherit",
  env: process.env,
  shell: isWindows,
});

if (result.error) {
  console.error("Could not start the Agent-Native build:", result.error.message);
  process.exit(1);
}
process.exit(result.status ?? 1);
