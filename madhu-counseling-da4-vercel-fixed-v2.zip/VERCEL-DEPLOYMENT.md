# Vercel deployment notes

This project uses Agent-Native on Nitro. Vercel should build it with the Nitro framework preset so Nitro's Vercel provider can emit the Vercel Build Output API directory (`.vercel/output`). Do not set `outputDirectory` to `.vercel/output` in `vercel.json`: that setting is for static output-directory handling and can cause Vercel to treat the project as a conventional Node/static app instead of consuming Nitro's Build Output API output.

## Deploy

1. Commit/push these files to the Git repository connected to the Vercel project.
2. The included `vercel.json` sets `framework` to `nitro` and uses `pnpm build`.
3. In Vercel Project Settings, set the Node.js version to 22.x or newer (the project declares Node >=22.22.0).
4. Redeploy and inspect the build log. Confirm the Agent-Native/Nitro build succeeds and emits `.vercel/output`.

If the same `No entrypoint found` error remains, check that Vercel's **Root Directory** is the folder containing this `package.json`, `vite.config.ts`, and `vercel.json`, and that the project is linked to this repository/branch. That error often means Vercel is still applying a conventional Node.js builder to the wrong project root rather than consuming the Nitro output.

## Runtime requirements

The code does not hard-code secrets or database credentials. Agent-Native production features require a persistent PostgreSQL `DATABASE_URL` and a stable `BETTER_AUTH_SECRET`. `BETTER_AUTH_URL` is optional and should match the public domain if fixed-origin auth redirects are needed.

If there is no database yet, database-backed framework features may require additional configuration. A successful deployment build alone does not verify database/auth runtime behavior.
