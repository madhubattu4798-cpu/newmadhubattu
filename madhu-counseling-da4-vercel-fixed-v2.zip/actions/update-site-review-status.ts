import { defineAction } from "@agent-native/core/action";
import { eq } from "drizzle-orm";
import { z } from "zod";

import { assertAdminPasscode } from "../server/admin.js";
import { getDb, schema } from "../server/db.js";

export default defineAction({
  description: "Approve or reject a client review. Requires the admin passcode.",
  schema: z.object({
    passcode: z.string().min(1).describe("Admin passcode"),
    id: z.string().min(1).describe("Review id"),
    status: z.enum(["approved", "rejected"]).describe("New review status"),
  }),
  run: async ({ passcode, id, status }) => {
    assertAdminPasscode(passcode);
    const db = getDb();
    const [row] = await db
      .update(schema.siteReviews)
      .set({ status })
      .where(eq(schema.siteReviews.id, id))
      .returning();
    return row;
  },
});
