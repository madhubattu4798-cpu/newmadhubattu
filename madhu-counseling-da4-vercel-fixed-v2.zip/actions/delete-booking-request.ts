import { defineAction } from "@agent-native/core/action";
import { eq } from "drizzle-orm";
import { z } from "zod";

import { getDb, schema } from "../server/db.js";

export default defineAction({
  description: "Delete a booking request by id.",
  schema: z.object({
    id: z.string().describe("Booking request id"),
  }),
  http: { method: "DELETE" },
  run: async ({ id }) => {
    const db = getDb();
    const [row] = await db
      .delete(schema.bookingRequests)
      .where(eq(schema.bookingRequests.id, id))
      .returning();
    return row;
  },
});
