import { defineAction } from "@agent-native/core/action";
import { desc, eq } from "drizzle-orm";
import { z } from "zod";

import { getDb, schema } from "../server/db.js";

export default defineAction({
  description: "List approved client reviews, newest first.",
  schema: z.object({}),
  http: { method: "GET" },
  run: async () => {
    const db = getDb();
    return db
      .select()
      .from(schema.siteReviews)
      .where(eq(schema.siteReviews.status, "approved"))
      .orderBy(desc(schema.siteReviews.createdAt));
  },
});
