import { defineAction } from "@agent-native/core/action";
import { z } from "zod";

import { assertAdminPasscode } from "../server/admin.js";
import { getDb, schema } from "../server/db.js";

export default defineAction({
  description: "Add a homepage photo. Requires the admin passcode.",
  schema: z.object({
    passcode: z.string().min(1).describe("Admin passcode"),
    src: z
      .string()
      .min(1)
      .max(2_000_000)
      .describe("Image as a data URL (data:image/...;base64,...)")
      .refine((value) => value.startsWith("data:image/"), "Must be an image data URL"),
    alt: z.string().min(1).max(200).describe("Image description"),
  }),
  run: async ({ passcode, src, alt }) => {
    assertAdminPasscode(passcode);
    const db = getDb();
    const [row] = await db
      .insert(schema.sitePhotos)
      .values({ id: crypto.randomUUID(), src, alt: alt.trim() })
      .returning();
    return row;
  },
});
