import { defineAction } from "@agent-native/core/action";
import { z } from "zod";

import { assertAdminPasscode } from "../server/admin.js";
import { getDb, schema } from "../server/db.js";

export default defineAction({
  description: "Add a client review. Requires the admin passcode.",
  schema: z.object({
    passcode: z.string().min(1).describe("Admin passcode"),
    clientName: z.string().min(1).max(120).describe("Client name or initials"),
    service: z.string().trim().max(120).optional().describe("Service the client received"),
    body: z.string().min(1).max(2000).describe("Review text"),
  }),
  run: async ({ passcode, clientName, service, body }) => {
    assertAdminPasscode(passcode);
    const db = getDb();
    const [row] = await db
      .insert(schema.siteReviews)
      .values({
        id: crypto.randomUUID(),
        clientName: clientName.trim(),
        service: service ?? "",
        body: body.trim(),
        status: "approved",
      })
      .returning();
    return row;
  },
});
