import { defineAction } from "@agent-native/core/action";
import { z } from "zod";

import { assertAdminPasscode } from "../server/admin.js";

export default defineAction({
  description: "Check the admin passcode before showing admin tools.",
  schema: z.object({
    passcode: z.string().min(1).describe("Admin passcode"),
  }),
  run: async ({ passcode }) => {
    assertAdminPasscode(passcode);
    return { ok: true };
  },
});
