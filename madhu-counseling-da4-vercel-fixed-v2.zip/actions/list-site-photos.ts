import { defineAction } from "@agent-native/core/action";
import { desc } from "drizzle-orm";
import { z } from "zod";

import { getDb, schema } from "../server/db.js";

export default defineAction({
  description: "List homepage photos, newest first.",
  schema: z.object({}),
  http: { method: "GET" },
  run: async () => {
    const db = getDb();
    return db
      .select()
      .from(schema.sitePhotos)
      .orderBy(desc(schema.sitePhotos.createdAt));
  },
});
