import { defineAction } from "@agent-native/core/action";
import { z } from "zod";

import { getDb, schema } from "../server/db.js";

export default defineAction({
  description: "Submit a public review. It stays hidden until an admin approves it.",
  schema: z.object({
    clientName: z.string().trim().min(1).max(120).describe("Client name or initials"),
    service: z.string().trim().min(1).max(120).describe("Service the client received"),
    body: z.string().trim().min(1).max(2000).describe("Review text"),
  }),
  run: async ({ clientName, service, body }) => {
    const db = getDb();
    await db.insert(schema.siteReviews).values({
      id: crypto.randomUUID(),
      clientName,
      service,
      body,
    });
    return { ok: true };
  },
});
