import { defineAction } from "@agent-native/core/action";
import { eq } from "drizzle-orm";
import { z } from "zod";

import { getDb, schema } from "../server/db.js";

export default defineAction({
  description: "Update the status of a booking request.",
  schema: z.object({
    id: z.string().describe("Booking request id"),
    status: z
      .enum(["new", "contacted", "confirmed", "closed"])
      .describe("New status"),
  }),
  run: async ({ id, status }) => {
    const db = getDb();
    const [row] = await db
      .update(schema.bookingRequests)
      .set({ status })
      .where(eq(schema.bookingRequests.id, id))
      .returning();
    return row;
  },
});
