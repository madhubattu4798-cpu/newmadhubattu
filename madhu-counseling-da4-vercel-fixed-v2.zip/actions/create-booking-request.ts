import { defineAction, fail } from "@agent-native/core/action";
import { sendEmail } from "@agent-native/core/server";
import { z } from "zod";

import {
  allowedSessionTypes,
  PAYMENT_OPTION_IDS,
  SESSION_TYPE_IDS,
  sessionAmount,
} from "../app/lib/booking-options.js";
import { getDb, schema } from "../server/db.js";

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function escapeHtml(value: string) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export default defineAction({
  description: "Create a booking request from the public booking form.",
  schema: z.object({
    fullName: z.string().min(1).describe("Client full name"),
    contact: z.string().min(1).describe("Email or phone number"),
    service: z.string().min(1).describe("Requested service"),
    sessionType: z.enum(SESSION_TYPE_IDS).describe("Session type"),
    preferredSlot: z.string().min(1).describe("Preferred date and time"),
    paymentOption: z.enum(PAYMENT_OPTION_IDS).optional().describe("Payment option for paid sessions"),
    paymentScreenshotUrl: z
      .string()
      .url()
      .startsWith("https://")
      .max(2000)
      .optional()
      .describe("Hosted URL of the payment screenshot"),
  }),
  run: async ({ fullName, contact, service, sessionType, preferredSlot, paymentOption, paymentScreenshotUrl }) => {
    if (!allowedSessionTypes(service).includes(sessionType)) {
      fail("This session type is not available for the selected service.", { statusCode: 400 });
    }

    const amount = sessionAmount(service, sessionType);
    if (amount > 0 && !paymentOption) {
      fail("Choose whether to pay in advance or during the session.", { statusCode: 400 });
    }
    if (paymentOption === "advance" && !paymentScreenshotUrl) {
      fail("Upload a screenshot of your payment to continue.", { statusCode: 400 });
    }
    const storedPaymentOption = amount > 0 ? paymentOption! : "";
    const storedScreenshotUrl = storedPaymentOption === "advance" ? paymentScreenshotUrl! : "";

    const db = getDb();
    const [row] = await db
      .insert(schema.bookingRequests)
      .values({
        id: crypto.randomUUID(),
        fullName: fullName.trim(),
        contact: contact.trim(),
        service,
        sessionType,
        preferredSlot: preferredSlot.trim(),
        amount,
        paymentOption: storedPaymentOption,
        paymentScreenshotUrl: storedScreenshotUrl,
      })
      .returning();

    if (EMAIL_PATTERN.test(row.contact)) {
      try {
        await sendEmail({
          to: row.contact,
          subject: "Thank you for reaching out to Madhu Battu Counseling",
          text: `Hello ${row.fullName},\n\nThank you for your enquiry. Madhu will be in touch to confirm your appointment.\n\nIf you are comfortable, we would be grateful for a short review of your experience. Simply reply to this email with your feedback, and it may be shared on the website with your permission.\n\nWarm regards,\nMadhu Battu Counseling`,
          html: `<p>Hello ${escapeHtml(row.fullName)},</p><p>Thank you for your enquiry. Madhu will be in touch to confirm your appointment.</p><p>If you are comfortable, we would be grateful for a short review of your experience. Simply reply to this email with your feedback, and it may be shared on the website with your permission.</p><p>Warm regards,<br>Madhu Battu Counseling</p>`,
        });
      } catch (error) {
        console.error("Review request email failed", error);
      }
    }

    return row;
  },
});
