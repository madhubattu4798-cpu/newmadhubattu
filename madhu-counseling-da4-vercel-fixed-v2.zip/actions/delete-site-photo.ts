import { defineAction } from "@agent-native/core/action";
import { eq } from "drizzle-orm";
import { z } from "zod";

import { assertAdminPasscode } from "../server/admin.js";
import { getDb, schema } from "../server/db.js";

export default defineAction({
  description: "Delete a homepage photo by id. Requires the admin passcode.",
  schema: z.object({
    passcode: z.string().min(1).describe("Admin passcode"),
    id: z.string().min(1).describe("Photo id"),
  }),
  http: { method: "DELETE" },
  run: async ({ passcode, id }) => {
    assertAdminPasscode(passcode);
    const db = getDb();
    const [row] = await db
      .delete(schema.sitePhotos)
      .where(eq(schema.sitePhotos.id, id))
      .returning();
    return row;
  },
});
