import { defineAction } from "@agent-native/core/action";
import { desc } from "drizzle-orm";
import { z } from "zod";

import { assertAdminPasscode } from "../server/admin.js";
import { getDb, schema } from "../server/db.js";

export default defineAction({
  description: "List all client reviews with their status, newest first. Requires the admin passcode.",
  schema: z.object({
    passcode: z.string().min(1).describe("Admin passcode"),
  }),
  run: async ({ passcode }) => {
    assertAdminPasscode(passcode);
    const db = getDb();
    return db
      .select()
      .from(schema.siteReviews)
      .orderBy(desc(schema.siteReviews.createdAt));
  },
});
