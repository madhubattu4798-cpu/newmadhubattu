import { defineAction } from "@agent-native/core/action";
import { desc } from "drizzle-orm";
import { z } from "zod";

import { assertAdminPasscode } from "../server/admin.js";
import { getDb, schema } from "../server/db.js";

export default defineAction({
  description: "List booking requests, newest first. Requires the admin passcode.",
  schema: z.object({
    passcode: z.string().min(1).describe("Admin passcode"),
    limit: z.number().int().min(1).max(200).default(50).describe("Max rows"),
  }),
  run: async ({ passcode, limit }) => {
    assertAdminPasscode(passcode);
    const db = getDb();
    return db
      .select()
      .from(schema.bookingRequests)
      .orderBy(desc(schema.bookingRequests.createdAt))
      .limit(limit);
  },
});
